# SQLi Lab

A simple web application built in PHP and MySQL to demonstrate SQL Injection vulnerabilities and how to test for them. This project is intended for educational purposes only.

## 🚀 Features

- User Registration and Login System
- Profile Page
- Demonstrates both vulnerable and protected SQL queries
- SQL Dump to set up the database

## ⚠️ Disclaimer

> This project is for **educational purposes only**. Do not deploy this application in a production environment or use it for malicious intent.

## 🛠️ Requirements

- PHP (>= 7.0)
- MySQL / MariaDB
- Apache Server (recommended: XAMPP or WAMP)

## 📦 Setup Instructions

1. Clone the repository or download the ZIP.
2. Move the project to your web server directory (e.g., `htdocs` in XAMPP).
3. Import the `sql_dump.sql` file into your MySQL server:
    - Open phpMyAdmin
    - Create a new database (e.g., `sqlilab`)
    - Import the `sql_dump.sql` file
4. Configure your database settings in `config.php`.

## 🔐 SQL Injection Testing

- This application contains vulnerable endpoints to help demonstrate SQL Injection attacks.
- Use tools like `sqlmap` or perform manual injection techniques for learning.

## 📁 File Structure

