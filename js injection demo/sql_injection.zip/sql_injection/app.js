const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Use body parser
app.use(bodyParser.urlencoded({ extended: false }));

// Serve static files (HTML, CSS, JS)
app.use(express.static(path.join(__dirname)));

// Create SQLite DB file (or open if it exists)
const db = new sqlite3.Database('./sqli-demo.db');

// Create users table (only once)
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    password TEXT
  )`);

  db.run(`INSERT OR IGNORE INTO users (username, password) VALUES
    ('admin', 'admin123'),
    ('user1', 'password123')`);
});

// Serve the HTML
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'inject.html'));
});

// Vulnerable login route
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;

  console.log("Executing:", query);

  db.all(query, [], (err, rows) => {
    if (err) return res.send("SQL Error: " + err.message);
    if (rows.length > 0) {
      res.send(`<h3>✅ Logged in as ${rows[0].username}</h3>`);
    } else {
      res.send('<h3>❌ Login failed</h3>');
    }
  });
});

// Start server
app.listen(port, () => {
  console.log(`🟢 Server running at http://localhost:${port}`);
});

